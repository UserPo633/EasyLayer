"""EasyLayer authenticated MCP bridge."""
